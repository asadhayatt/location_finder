<?php

namespace App\Http\Controllers\Location;

use App\Http\Controllers\Controller;
use App\Models\Address;
use Illuminate\Http\Request;

use Stevebauman\Location\Facades\Location;

class LocationController extends Controller
{
    public function index(){
    //  return get_ip();

    // $ip = get_ip();
        // $ip = '103.239.147.187'; //For static IP address get
        $ip = '101.53.224.0'; //Dynamic IP address get
        $data = Location::get($ip);
        $address = new Address();
        $address->ip = $data->ip;
        $address->countryName = $data->countryName;
        $address->countryCode = $data->countryCode;
        $address->regionCode = $data->regionCode;
        $address->regionName = $data->regionName;
        $address->cityName = $data->cityName;
        $address->zipCode = $data->zipCode;
        $address->postalCode = $data->postalCode;
        $address->latitude = $data->latitude;
        $address->longitude = $data->longitude;
        $address->areaCode = $data->areaCode;
        $address->timezone = $data->timezone;
        $address->save();

        return "data saved";
        return view('location.location',get_defined_vars());
    }
}
