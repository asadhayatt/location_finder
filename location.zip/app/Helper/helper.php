<?php

use Stevebauman\Location\Facades\Location;
use Jenssegers\Agent\Agent;

// get Ip from User Device and getting location

if(! function_exists('get_ip'))
{
    function get_ip()
    {
        $ipData =  $_SERVER["REMOTE_ADDR"];
        return $ipData;
    }
}
