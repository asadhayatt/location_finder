<html>
<head>
	<title>Welcome </title>
</head>
<body style="text-align: center;">

    <h1><?php echo e(get_ip()); ?></h1>


	<h1> Laravel 9 Get Current User Location Using IP Address - Techsolutionstuff </h1>
	<div style="border:1px solid black; margin-left: 300px; margin-right: 300px;">
	<h3>IP: <?php echo e($data->ip); ?></h3>
	<h3>Country Name: <?php echo e($data->countryName); ?></h3>
	<h3>Country Code: <?php echo e($data->countryCode); ?></h3>
	<h3>Region Code: <?php echo e($data->regionCode); ?></h3>
	<h3>Region Name: <?php echo e($data->regionName); ?></h3>
	<h3>City Name: <?php echo e($data->cityName); ?></h3>
	<h3>Zipcode: <?php echo e($data->zipCode); ?></h3>
	<h3>Latitude: <?php echo e($data->latitude); ?></h3>
	<h3>Longitude: <?php echo e($data->longitude); ?></h3>
	</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\location\resources\views/location/location.blade.php ENDPATH**/ ?>